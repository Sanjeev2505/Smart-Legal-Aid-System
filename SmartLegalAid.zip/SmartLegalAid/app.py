# app.py  – Smart Legal Aid System (Phase 1)

import streamlit as st

# --- Streamlit Page Configuration ---
st.set_page_config(
    page_title="Smart Legal Aid System",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- Custom Dark Theme Styling ---
st.markdown("""
    <style>
    .stApp {
        background-color: #0e1117;
        color: #f5f5f5;
    }
    .css-18e3th9, .css-1d391kg {
        background-color: #0e1117;
    }
    .stSidebar {
        background-color: #111827;
    }
    h1, h2, h3, h4, h5 {
        color: #f5f5f5;
    }
    .stButton>button {
        background-color: #1e40af;
        color: white;
        border: none;
        border-radius: 6px;
        padding: 0.5em 1.2em;
        font-weight: 600;
        cursor: pointer;
    }
    .stButton>button:hover {
        background-color: #1d4ed8;
        color: #fff;
    }
    </style>
""", unsafe_allow_html=True)

# --- Home Page Content ---
st.title("⚖️ Smart Legal Aid System")
st.write("""
Welcome to the **Smart Legal Aid System**, an AI-powered platform designed to assist
users in analysing legal documents, assessing case risk, finding relevant lawyers,
and retrieving similar past cases.
""")

st.markdown("---")

st.header("📂 Modules Included")
cols = st.columns(3)
modules = [
    ("Lawyer Recommendation", "Recommends lawyers based on case type and location."),
    ("Case Similarity Search", "Finds similar past legal cases or judgments."),
    ("Clause Extraction", "Identifies key or risky clauses from uploaded documents."),
    ("AI Legal Chatbot", "Answers basic legal queries via AI."),
]
for i, (title, desc) in enumerate(modules):
    with cols[i % 3]:
        st.subheader(f"✅ {title}")
        st.caption(desc)

st.markdown("---")

st.info("Use the sidebar to navigate to each module.")

# --- Sidebar ---
st.sidebar.title("🧭 Navigation")
st.sidebar.success("Select a module from the list below:")

# The sidebar automatically populates when /pages directory exists in Streamlit.
# Just ensure all your feature files are in `/pages/`.

st.sidebar.markdown("""
- **1. Lawyer Recommendation**
- **2. Case Similarity Search**
- **3. Clause Extraction**
- **4. AI Legal Chatbot**
""")
