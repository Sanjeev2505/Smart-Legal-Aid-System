import nltk

# download required tokenizers
nltk.download('punkt')
nltk.download('punkt_tab')

print("✅ NLTK punkt and punkt_tab downloaded successfully!")
