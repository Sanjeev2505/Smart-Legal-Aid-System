import streamlit as st
from utils.case_similarity import load_case_data, load_model, find_similar_cases

st.set_page_config(page_title="Case Similarity Finder")

st.title("⚖️ Case Similarity Finder")
st.write("""
Find **past cases similar to a given legal description** using semantic embeddings (Sentence-BERT).
""")

@st.cache_resource
def get_resources():
    df = load_case_data()
    model = load_model()
    return df, model

df, model = get_resources()

query = st.text_area("📝 Describe the new case or situation:")

if st.button("🔍 Find Similar Cases"):
    if query.strip():
        with st.spinner("Analyzing and comparing with existing cases..."):
            results = find_similar_cases(query, df, model, top_n=5)

            # Dynamically show only existing columns
            show_cols = ["Title", "Summary", "Similarity (%)"]
            for col in ["Outcome", "Category"]:
                if col in results.columns:
                    show_cols.append(col)

            st.success("✅ Most Similar Cases Found:")
            st.dataframe(results[show_cols])
    else:
        st.warning("Please enter a case description to analyze.")
