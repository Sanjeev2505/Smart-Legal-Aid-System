import streamlit as st
from utils.legal_chatbot import load_chatbot, answer_question

# Page setup
st.set_page_config(page_title="AI Legal Chatbot")

st.title("💬 AI Legal Chatbot")
st.write("""
Ask your legal questions — powered by **Legal-BERT** and your offline FAQ dataset.
You can ask about common legal terms such as *FIR, Bail, Divorce, Contract, Cybercrime, Defamation, Cheque Bounce*, etc.
""")

# Load QA model once
@st.cache_resource
def get_chatbot():
    return load_chatbot()

qa = get_chatbot()

# Load context from FAQ file
try:
    with open("data/legal_faq.txt", "r", encoding="utf-8") as f:
        context = f.read()
except FileNotFoundError:
    st.error("❌ 'data/legal_faq.txt' not found! Please make sure the file exists in your data folder.")
    st.stop()

# User input
question = st.text_input("Enter your legal question (e.g., What is bail?)")

if st.button("Ask"):
    if question.strip():
        with st.spinner("Analyzing your question with Legal-BERT..."):
            ans, conf = answer_question(qa, question, context)
            if "Error" in ans:
                st.error(ans)
            else:
                st.success(f"**Answer:** {ans}")
    else:
        st.warning("Please enter a question before asking.")


