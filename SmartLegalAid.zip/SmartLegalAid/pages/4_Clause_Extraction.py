import streamlit as st
from utils.clause_extractor import load_extractor, extract_clauses

st.set_page_config(page_title="Clause Extraction")

st.title("📄 Clause Extraction (Semantic Clause Finder)")
st.write("""
Upload or paste a contract to extract **full important clauses** using Sentence-BERT similarity ranking.
""")

@st.cache_resource
def get_model():
    return load_extractor()

model = get_model()

uploaded = st.file_uploader("📂 Upload Contract / Agreement (.txt)", type=["txt"])
text_input = st.text_area("Or paste legal document text here:")

if st.button("⚙️ Extract Clauses"):
    text = ""
    if uploaded:
        text = uploaded.read().decode("utf-8", errors="ignore")
    elif text_input.strip():
        text = text_input.strip()

    if not text:
        st.warning("Please upload or paste some text first.")
    else:
        with st.spinner("Analyzing document..."):
            clauses = extract_clauses(text, model, top_n=10)
            st.success("✅ Key Clauses Identified:")
            for i, clause in enumerate(clauses, 1):
                st.markdown(f"**{i}.** {clause}")



