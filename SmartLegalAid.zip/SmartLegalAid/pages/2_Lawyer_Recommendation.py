import streamlit as st
from utils.lawyer_recommender import load_lawyer_data, load_sentence_model, recommend_lawyers

st.title("👨‍⚖️ Smart Lawyer Recommendation")

@st.cache_resource
def get_resources():
    df = load_lawyer_data("data/Lawyers_1000_Dataset.csv")
    model = load_sentence_model()
    return df, model

df, model = get_resources()

case_desc = st.text_area("Describe your case:")
if st.button("Find Lawyers"):
    if not case_desc.strip():
        st.warning("Please enter a case description.")
    else:
        results = recommend_lawyers(case_desc, df, model, top_k=5)
        if results.empty:
            st.error("No suitable lawyers found.")
        else:
            st.write(f"**Detected Case Type:** {results['DetectedType'].iloc[0]}")
            st.dataframe(results[["Name", "Specialization", "Rating", "Experience", "Similarity (%)", "FinalScore (%)"]])


