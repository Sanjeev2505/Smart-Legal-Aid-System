from transformers import pipeline

# Use a real QA model
MODEL_NAME = "deepset/roberta-base-squad2"

def load_chatbot():
    qa = pipeline("question-answering", model=MODEL_NAME, tokenizer=MODEL_NAME)
    return qa

def answer_question(qa, question, context):
    try:
        res = qa(question=question, context=context)
        return res["answer"], round(res["score"] * 100, 2)
    except Exception as e:
        return f"Error: {e}", 0

