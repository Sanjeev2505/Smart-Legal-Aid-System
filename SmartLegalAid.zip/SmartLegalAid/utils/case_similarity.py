# utils/case_similarity.py
import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity

MODEL_NAME = "sentence-transformers/all-mpnet-base-v2"

def load_case_data(path="data/Case_Similarity_Dataset.csv"):
    df = pd.read_csv(path)
    if "Summary" not in df.columns:
        raise ValueError("CSV must contain a 'Summary' column for case descriptions.")
    return df

import pandas as pd
import re

def load_case_data(path="data/Case_Similarity_Dataset.csv"):
    
    df = pd.read_csv(path)
    # Handle missing values
    df["Summary"] = df["Summary"].fillna("")
    if "Title" in df.columns:
        df["Title"] = df["Title"].fillna("")
    if "Type" in df.columns:
        df["Type"] = df["Type"].fillna("Unknown")
    if "Year" in df.columns:
        df["Year"] = df["Year"].fillna(0)

    # Convert Year to numeric
    if "Year" in df.columns:
        df["Year"] = pd.to_numeric(df["Year"], errors="coerce").fillna(0)

    # Text cleaning function
    def clean_text(text):
        text = str(text).lower()
        text = re.sub(r"\s+", " ", text)   # remove extra spaces
        return text.strip()

    # Apply cleaning
    df["Summary"] = df["Summary"].apply(clean_text)
    if "Title" in df.columns:
        df["Title"] = df["Title"].apply(clean_text)

    # Remove duplicate rows
    df.drop_duplicates(inplace=True)

    return df

def load_model():
    return SentenceTransformer(MODEL_NAME)

def find_similar_cases(query, df, model, top_n=5):
    """Find semantically similar cases using embeddings."""
    case_texts = df["Summary"].fillna("").tolist()

    # Encode input and all case summaries
    query_emb = model.encode([query])
    case_embs = model.encode(case_texts)

    # Compute cosine similarity
    sims = cosine_similarity(query_emb, case_embs)[0]
    top_idx = np.argsort(sims)[::-1][:top_n]

    results = df.iloc[top_idx].copy()
    results["Similarity (%)"] = (sims[top_idx] * 100).round(2)
    return results
