# utils/lawyer_recommender.py

import pandas as pd
import numpy as np
import re
import warnings

from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from transformers import pipeline

# ======================================================
# MODEL NAMES
# ======================================================
EMBEDDING_PRIMARY = "law-ai/InLegalBERT"  # legal-domain; will try first
EMBEDDING_FALLBACK = "sentence-transformers/all-mpnet-base-v2"
CASE_TYPE_MODEL_NAME = "facebook/bart-large-mnli"

# global caches (so models load only once)
_embedding_model = None
_case_type_classifier = None


# ======================================================
# LOADING LAWYER DATA
# ======================================================
import pandas as pd
import re

def load_lawyer_data(path: str = "data/Lawyers_1000_Dataset.csv") -> pd.DataFrame:
    """
    Load and preprocess lawyer dataset from CSV.

    Steps:
    - Load CSV with encoding handling
    - Validate required columns
    - Handle missing values
    - Clean text data
    - Convert numeric fields
    - Remove duplicates
    - Create combined text feature
    """

    # Load dataset with encoding fallback
    try:
        df = pd.read_csv(path, encoding="utf-8")
    except UnicodeDecodeError:
        df = pd.read_csv(path, encoding="latin1")
    except Exception as e:
        raise FileNotFoundError(f"❌ Error loading '{path}': {e}")
    
    # Handle missing values
    df["Name"] = df.get("Name", "").fillna("Unknown")
    df["Specialization"] = df["Specialization"].fillna("")
    df["Description"] = df["Description"].fillna("")
    df["Rating"] = df["Rating"].fillna(0)
    df["Experience"] = df["Experience"].fillna(0)

    # Convert numeric columns safely
    df["Rating"] = pd.to_numeric(df["Rating"], errors="coerce").fillna(0)
    df["Experience"] = pd.to_numeric(df["Experience"], errors="coerce").fillna(0)

    # Text cleaning function
    def clean_text(text):
        text = str(text).lower()
        text = re.sub(r"\s+", " ", text)  # remove extra spaces
        return text.strip()

    # Apply cleaning
    df["Specialization"] = df["Specialization"].apply(clean_text)
    df["Description"] = df["Description"].apply(clean_text)

    # Remove duplicates
    df.drop_duplicates(inplace=True)

    return df


# ======================================================
# LOADING MODELS
# ======================================================
def load_sentence_model():
    """
    Load sentence embedding model.
    Tries InLegalBERT first; falls back to all-mpnet-base-v2 if that fails.
    Also initializes zero-shot classifier for case type detection.
    Returns the embedding model.
    """
    global _embedding_model, _case_type_classifier

    # ---- Load embedding model (cached) ----
    if _embedding_model is None:
        try:
            _embedding_model = SentenceTransformer(EMBEDDING_PRIMARY)
            print(f"✅ Loaded embedding model: {EMBEDDING_PRIMARY}")
        except Exception as e:
            warnings.warn(
                f"⚠️ Could not load {EMBEDDING_PRIMARY}: {e}. Falling back to {EMBEDDING_FALLBACK}"
            )
            _embedding_model = SentenceTransformer(EMBEDDING_FALLBACK)
            print(f"✅ Loaded embedding model: {EMBEDDING_FALLBACK}")

    # ---- Load zero-shot classifier (cached) ----
    if _case_type_classifier is None:
        _case_type_classifier = pipeline(
            "zero-shot-classification",
            model=CASE_TYPE_MODEL_NAME,
            device_map="auto"
        )
        print(f"✅ Loaded case-type classifier: {CASE_TYPE_MODEL_NAME}")

    return _embedding_model  # classifier stays global


# ======================================================
# CASE TYPE DETECTION (ZERO-SHOT)
# ======================================================
def detect_case_type(text: str) -> str:
    """
    Predicts case type (Criminal, Civil, Family, Corporate, Cyber, etc.)
    using zero-shot classification. Falls back to simple rules if needed.
    """
    global _case_type_classifier
    if _case_type_classifier is None:
        # ensure models are loaded
        load_sentence_model()

    text = text.strip()
    if not text:
        return "General"

    labels = ["Criminal", "Civil", "Family", "Corporate", "Cyber", "Consumer", "Labour", "Tax"]
    try:
        result = _case_type_classifier(text, candidate_labels=labels)
        case_type = result["labels"][0]
        return case_type
    except Exception as e:
        warnings.warn(f"⚠️ Zero-shot case-type detection failed: {e}. Falling back to regex rules.")
        return _fallback_detect_specialization(text)


# Fallback keyword-based detection (used only if zero-shot fails)
_keyword_map_fallback = {
    "rape": "Criminal",
    "murder": "Criminal",
    "kill": "Criminal",
    "killed": "Criminal",
    "assault": "Criminal",
    "fraud": "Criminal",
    "cheating": "Criminal",
    "robbery": "Criminal",
    "theft": "Criminal",
    "ipc": "Criminal",
    "fir": "Criminal",

    "property": "Civil",
    "contract": "Civil",
    "agreement": "Civil",
    "land": "Civil",
    "possession": "Civil",

    "divorce": "Family",
    "custody": "Family",
    "marriage": "Family",
    "maintenance": "Family",
    "domestic": "Family",

    "company": "Corporate",
    "corporate": "Corporate",
    "employee": "Corporate",
    "employer": "Corporate",

    "cyber": "Cyber",
    "hacking": "Cyber",
    "data": "Cyber",
    "phishing": "Cyber",
    "internet": "Cyber",
}


def _fallback_detect_specialization(text: str) -> str:
    text = text.lower()
    # Prioritise obvious criminal words
    for w in ["murder", "kill", "killed", "rape", "assault", "robbery", "theft", "ipc", "fir"]:
        if w in text:
            return "Criminal"
    for k, v in _keyword_map_fallback.items():
        if re.search(rf"\b{k}\b", text):
            return v
    return "General"


# ======================================================
# HYBRID LAWYER RECOMMENDATION
# ======================================================
def recommend_lawyers(case_desc: str,
                      df: pd.DataFrame,
                      model: SentenceTransformer,
                      top_k: int = 5) -> pd.DataFrame:
    """
    Recommend best lawyers for a given case description.

    Steps:
      1. Detect case type via zero-shot classification.
      2. Filter lawyers by Specialization containing the case type.
      3. Compute semantic similarity between case desc and lawyer profile.
      4. Combine similarity + rating + experience into a final score.
      5. Return top_k lawyers with scores.

    Returns:
        DataFrame with columns:
        - Name
        - Specialization
        - Description
        - Rating
        - Experience
        - Similarity (%)
        - FinalScore (%)
        - DetectedType
    """
    if not isinstance(df, pd.DataFrame) or df.empty:
        return pd.DataFrame()

    if not case_desc or len(case_desc.strip()) < 5:
        return pd.DataFrame()

    # 1) Detect case type
    case_type = detect_case_type(case_desc)

    # 2) Filter lawyers by specialization text match
    subset = df.copy()
    try:
        subset = df[df["Specialization"].str.contains(case_type, case=False, na=False)]
        if subset.empty:
            subset = df.copy()
    except Exception:
        subset = df.copy()

    if subset.empty:
        return pd.DataFrame()

    # 3) Prepare embeddings
    case_emb = model.encode([case_desc])
    # combine specialization + description as lawyer profile text
    lawyer_texts = (
        subset["Specialization"].fillna("").astype(str) + " " +
        subset["Description"].fillna("").astype(str)
    ).tolist()

    lawyer_embs = model.encode(lawyer_texts)
    sims = cosine_similarity(case_emb, lawyer_embs)[0]  # 1 x N → N

    # 4) Collect numeric features
    rating = subset["Rating"].fillna(0).to_numpy(dtype=float)
    exp = subset["Experience"].fillna(0).to_numpy(dtype=float)

    # Normalize similarity
    if sims.max() - sims.min() < 1e-9:
        sim_norm = np.ones_like(sims)
    else:
        sim_norm = (sims - sims.min()) / (sims.max() - sims.min() + 1e-9)

    # Normalize rating (0–5 → 0–1)
    rating_norm = np.clip(rating / 5.0, 0, 1)

    # Normalize experience
    max_exp = exp.max()
    exp_norm = exp / max_exp if max_exp > 0 else np.zeros_like(exp)

    # 5) Hybrid score (tunable weights)
    final_score = (
        0.6 * sim_norm +
        0.3 * rating_norm +
        0.1 * exp_norm
    )

    if len(final_score) == 0:
        return pd.DataFrame()

    top_k = min(top_k, len(final_score))
    top_idx = np.argsort(final_score)[::-1][:top_k]

    subset = subset.reset_index(drop=True)
    results = subset.iloc[top_idx].copy()
    results["Similarity (%)"] = (sims[top_idx] * 100).round(2)
    results["FinalScore (%)"] = (final_score[top_idx] * 100).round(2)
    results["DetectedType"] = case_type

    # sort by FinalScore descending
    results = results.sort_values(by="FinalScore (%)", ascending=False).reset_index(drop=True)
    return results
