# utils/clause_extractor.py
import re
import numpy as np
from sentence_transformers import SentenceTransformer, util
import nltk

# download sentence tokenizer
nltk.download('punkt', quiet=True)

def load_extractor():
    """Load Sentence-BERT for sentence-level clause extraction."""
    return SentenceTransformer("all-mpnet-base-v2")

def clean_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text)
    return text.strip()

def split_sentences(text: str):
    from nltk.tokenize import sent_tokenize
    return [s.strip() for s in sent_tokenize(text) if len(s.strip()) > 10]

def extract_clauses(text, model, top_n=8):
    """Extract most important full sentences (clauses) using semantic similarity."""
    text = clean_text(text)
    sentences = split_sentences(text)
    if len(sentences) < 2:
        return ["⚠️ Please provide a longer document (at least 3–4 sentences)."]

    # Compute embeddings
    doc_emb = model.encode(text, convert_to_tensor=True)
    sent_embs = model.encode(sentences, convert_to_tensor=True)

    # Compute cosine similarities
    sims = util.cos_sim(doc_emb, sent_embs)[0].cpu().numpy()

    # Get top sentences by semantic similarity
    top_idx = np.argsort(sims)[::-1][:top_n]
    top_sentences = [sentences[i] for i in top_idx]

    return top_sentences


